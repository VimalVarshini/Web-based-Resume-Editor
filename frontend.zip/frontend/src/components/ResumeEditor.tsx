import React, { useState } from 'react';
import SectionEditor from './SectionEditor';
import { enhanceSection, saveResume } from '../api';

const initialResume = {
  name: 'John Doe',
  summary: 'Experienced developer...',
  experience: 'Worked at XYZ...',
  education: 'B.Tech in CS...',
  skills: 'JavaScript, React, Python',
};

function ResumeEditor() {
  const [resume, setResume] = useState(initialResume);
  const [loading, setLoading] = useState(false);

  const handleEnhance = async (section: keyof typeof resume) => {
    const improved = await enhanceSection(section, resume[section]);
    setResume({ ...resume, [section]: improved });
  };

  const handleChange = (section: keyof typeof resume, value: string) => {
    setResume({ ...resume, [section]: value });
  };

  const handleSave = async () => {
    setLoading(true);
    await saveResume(resume);
    setLoading(false);
    alert('Resume saved successfully!');
  };

  const handleDownload = () => {
    const blob = new Blob([JSON.stringify(resume, null, 2)], {
      type: 'application/json',
    });
    const link = document.createElement('a');
    link.href = URL.createObjectURL(blob);
    link.download = 'resume.json';
    link.click();
  };

  return (
    <div>
      {Object.entries(resume).map(([key, value]) => (
        <SectionEditor
          key={key}
          section={key}
          value={value}
          onChange={(val) => handleChange(key as keyof typeof resume, val)}
          onEnhance={() => handleEnhance(key as keyof typeof resume)}
        />
      ))}
      <div className="buttons-container">
        <button onClick={handleSave} disabled={loading}>
          {loading ? 'Saving...' : '💾 Save Resume'}
        </button>
        <button onClick={handleDownload}>📥 Download JSON</button>
      </div>
    </div>
  );
}

export default ResumeEditor;
