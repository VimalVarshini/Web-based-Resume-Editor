import React from 'react';

interface Props {
  section: string;
  value: string;
  onChange: (value: string) => void;
  onEnhance: () => void;
}

function SectionEditor({ section, value, onChange, onEnhance }: Props) {
  const label = section.charAt(0).toUpperCase() + section.slice(1);

  return (
    <div className="editor-section">
      <label htmlFor={section}>{label}</label>
      <textarea
        id={section}
        rows={4}
        value={value}
        onChange={(e) => onChange(e.target.value)}
        placeholder={`Enter your ${label.toLowerCase()}...`}
      />
      <div style={{ display: 'flex', justifyContent: 'flex-end' }}>
        <button onClick={onEnhance}>✨ Enhance with AI</button>
      </div>
    </div>
  );
}

export default SectionEditor;
