// src/api.ts
import axios from 'axios';

const BASE_URL = 'http://localhost:8000';

// ✔️ Fix here: send correct JSON format expected by FastAPI
export async function enhanceSection(section: string, content: string) {
  const response = await axios.post(`${BASE_URL}/ai-enhance`, {
    section: section,
    content: content,
  });
  return response.data.improved;
}

export async function saveResume(resume: any) {
  const response = await axios.post(`${BASE_URL}/save-resume`, resume);
  return response.data.message;
}
