// index.tsx - React entry point
import React from 'react'; // Import core React library
import ReactDOM from 'react-dom/client'; // React DOM renderer
import App from './App'; // Main App component
import './index.css'; // Global styles

// Mount the App component to the <div id="root"> in index.html
ReactDOM.createRoot(document.getElementById('root')!).render(<App />);
