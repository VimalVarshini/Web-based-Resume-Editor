import React from 'react';
import ResumeEditor from './components/ResumeEditor';
import './index.css';

function App() {
  return (
    <div className="container">
      <div className="editor-box">
        <h1>Resume Editor</h1>
        <ResumeEditor />
      </div>
    </div>
  );
}

export default App;
