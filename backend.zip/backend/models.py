from pydantic import BaseModel

class EnhanceRequest(BaseModel):
    section: str
    content: str

class SaveResumeRequest(BaseModel):
    name: str
    summary: str
    experience: str
    education: str
    skills: str
