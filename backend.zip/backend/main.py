from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from models import EnhanceRequest, SaveResumeRequest
import json
import os

app = FastAPI()

# Enable CORS so frontend can connect
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # You can restrict this to http://localhost:5173 in prod
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# AI Enhancement (Mocked)
@app.post("/ai-enhance")
async def enhance_section(req: EnhanceRequest):
    improved = f"✨ Enhanced {req.section.capitalize()} ✨\n\n{req.content.strip()} (rephrased)"
    return {"improved": improved}

# Save resume as JSON file
@app.post("/save-resume")
async def save_resume(data: SaveResumeRequest):
    try:
        with open("resume.json", "w", encoding="utf-8") as f:
            json.dump(data.dict(), f, indent=4)
        return {"message": "Resume saved successfully."}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

# Optional: Get resume data (for future use)
@app.get("/get-resume")
async def get_resume():
    if not os.path.exists("resume.json"):
        return {"message": "No resume found", "resume": {}}
    with open("resume.json", "r", encoding="utf-8") as f:
        data = json.load(f)
    return {"resume": data}
